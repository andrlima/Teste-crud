package br.com.leo.mvc.logica;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.leo.cadastro.dao.ClienteDao;
import br.com.leo.cadastro.modelo.Cliente;

public class ListaClienteLogica  implements Logica{
	
	public String executa(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		List<Cliente> clientes = new ClienteDao().getLista();
		
		request.setAttribute("clientes", clientes);
		
		return "lista-contatos.jsp";
		
		
	}

}
