package br.com.leo.mvc.logica;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.leo.cadastro.dao.ClienteDao;
import br.com.leo.cadastro.modelo.Cliente;

@WebServlet("/atualizarCliente")
public class AlterarCliente extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		PrintWriter out = response.getWriter();
		
		long id = Long.parseLong(request.getParameter("id"));
		
		String nome = request.getParameter("nome");
		
		int cpf  = Integer.parseInt(request.getParameter("cpf"));
		int telefone = Integer.parseInt(request.getParameter("telefone"));
		
		String dataEmTexto = request.getParameter("dataNascimento");
		
		Calendar dataNascimento = null;
		
		try {
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dataEmTexto);
			dataNascimento = Calendar.getInstance();
			dataNascimento.setTime(date);
		}
		catch(ParseException e) {
			out.println("Erro na convers�o da data!");
			return;
		}
		
		String email = request.getParameter("email");
		String nomePai = request.getParameter("nomePai");
		String nomeMae  = request.getParameter("nomeMae");
				
		Cliente cliente = new Cliente();
		
		cliente.setId(id);
		
		cliente.setNome(nome);
		cliente.setCpf(cpf);
		cliente.setNomePai(nomePai);
		cliente.setNomeMae(nomeMae);
		cliente.setTelefone(telefone);
		cliente.setEmail(email);
		
		ClienteDao dao = new ClienteDao();
		dao.atualizar(cliente);
		
		RequestDispatcher rd = request.getRequestDispatcher("/alterar-cliente.jsp");
		rd.forward(request, response);
		
		
	}
		

}
