package br.com.leo.mvc.logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.leo.cadastro.dao.ClienteDao;
import br.com.leo.cadastro.modelo.Cliente;

public class RemoveClienteLogica implements Logica{

	@Override
	public String executa(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		long id = Long.parseLong(request.getParameter("id"));
		
		Cliente cliente = new Cliente();
		cliente.setId(id);
		
		ClienteDao dao = new ClienteDao();
		dao.excluir(cliente);
		
		System.out.println("Excluindo cliente...");
		
		return "lista-cliente.jsp";
	}

}
