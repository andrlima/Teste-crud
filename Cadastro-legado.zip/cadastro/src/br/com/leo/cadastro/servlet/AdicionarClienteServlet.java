package br.com.leo.cadastro.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.leo.cadastro.dao.ClienteDao;
import br.com.leo.cadastro.modelo.Cliente;

@WebServlet("/adicionarCliente")
public class AdicionarClienteServlet extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		PrintWriter out = response.getWriter();
		
		String nome = request.getParameter("nome");
		int cpf  = Integer.parseInt(request.getParameter("cpf"));
		String dataEmTexto = request.getParameter("dataNascimento");
		
		Calendar dataNascimento = null;
		
		try {
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dataEmTexto);
			dataNascimento = Calendar.getInstance();
			dataNascimento.setTime(date);
		}
		catch(ParseException e) {
			out.println("Erro na convers�o da data!");
			return;
		}
		
		int telefone = Integer.parseInt(request.getParameter("telefone"));
		String email = request.getParameter("email");
		String nomePai = request.getParameter("nomePai");
		String nomeMae  = request.getParameter("nomeMae");
		
		Cliente cliente = new Cliente();
		
		cliente.setNome(nome);
		cliente.setCpf(cpf);
		cliente.setDataNascimento(dataNascimento);
		
		cliente.setNomePai(nomePai);
		cliente.setNomeMae(nomeMae);
		cliente.setTelefone(telefone);
		cliente.setEmail(email);
		
		ClienteDao dao = new ClienteDao();
		dao.adicionar(cliente);
		
		
		RequestDispatcher rd = request.getRequestDispatcher("/cliente-adicionado.jsp");
		rd.forward(request, response);
		
		
	}
	

}
